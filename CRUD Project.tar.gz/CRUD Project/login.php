<?php
    $mysql_host = "localhost";
    $mysql_username = "cadenbullard";
    $mysql_password = "cadenbullard";
    $mysql_database = "CRUD";
?>
